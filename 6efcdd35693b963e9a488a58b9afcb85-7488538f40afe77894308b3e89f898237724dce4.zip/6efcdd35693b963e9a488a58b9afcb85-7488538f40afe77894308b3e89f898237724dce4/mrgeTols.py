if __name__ == '__main__':
    st=input('enter the strin')
    n=int(input("enter the number"))
    x=len(st)
    a=[]
    b=[]
    z=1
    z1=0
    for i in range(0,x,n):
    for i in range(0,x,n):
        temp=st[i]
        z1=z1+1
        z=n*z1
        for j in range(i+1,z):
            temp=temp+st[j]
        a.append(temp)
    y=len(a)
    for k in range(0,y):
        temp1=a[k][0]
        for l in range(1,3):
            if a[k][l] in temp1:
                pass
            else:
                temp1=temp1+a[k][l]
        b.append(temp1)
    le=len(b)
    for p in range(0,le):
        print(b[p])
